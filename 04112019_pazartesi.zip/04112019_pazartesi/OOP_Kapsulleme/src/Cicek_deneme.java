import java.util.ArrayList;

public class Cicek_deneme {

	public static void main(String[] args) {
		/*
		 String renk, String isim, String tur, String mevsim, boolean koku, boolean diken, boolean saksi,
			boolean meyve, int omur, int yukseklik, int yaprakSayisi
		 */
		ArrayList<Cicek> cicekler = new ArrayList<>();
		cicekler.add(new Cicek("K�rm�z�","G�l","G�l","Yaz",true,true,true,false,120,150,50));
		cicekler.add(new Cicek("Beyaz","Lale","G�l","Yaz",true,false,true,false,90,40,10));
		cicekler.add(new Cicek("Mor","Karanfil","G�l","Yaz",true,false,true,false,100,30,12));
		
		for (int i = 0; i < cicekler.size(); i++) {
			System.out.println("�i�e�in Ad�: "+cicekler.get(i).getIsim());
			System.out.println("�i�e�in T�r�: "+cicekler.get(i).getTur());
			System.out.println("�i�e�in Rengi: "+cicekler.get(i).getRenk());
			System.out.println("�i�e�in Mevsimi: "+cicekler.get(i).getMevsim());
			
			if(cicekler.get(i).isDiken()) {
				System.out.println("�i�ek dikenli mi? : Evet");
			}else {
				System.out.println("�i�ek dikenli mi? : Hay�r");
			}
			
			String koku = cicekler.get(i).isKoku() ? "�i�ek kokulu mu? : Evet" : "�i�ek kokulu mu? : Hay�r";
			System.out.println(koku);
			String meyve = cicekler.get(i).isMeyve() ? "�i�ek meyveli mi? : Evet" : "�i�ek meyveli mi? : Hay�r";
			System.out.println(meyve);
			
			System.out.println("�i�e�in maksimum y�ksekli�i: "+cicekler.get(i).getYukseklik());
			System.out.println("�i�e�in yaprak say�s�: "+cicekler.get(i).getYaprakSayisi());
			System.out.println("�i�e�in �mr�(G�n say�s�): "+cicekler.get(i).getOmur());
			
			System.out.println(cicekler.get(i));
			
			System.out.println("---");
		}

	}

}
