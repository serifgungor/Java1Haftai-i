
public class Insan {
	
	private String ad;
	private String soyad;
	private int dogumYili;
	private String yasadigiUlke;
	private char cinsiyet;
	private double boy;
	private double kilo;
	
	public Insan() {
	}

	public Insan(String ad, String soyad, int dogumYili, String yasadigiUlke, char cinsiyet, double boy, double kilo) {
		this.ad = ad;
		this.soyad = soyad;
		this.dogumYili = dogumYili;
		this.yasadigiUlke = yasadigiUlke;
		this.cinsiyet = cinsiyet;
		this.boy = boy;
		this.kilo = kilo;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getSoyad() {
		return soyad;
	}

	public void setSoyad(String soyad) {
		this.soyad = soyad;
	}

	public int getDogumYili() {
		return dogumYili;
	}

	public void setDogumYili(int dogumYili) {
		this.dogumYili = dogumYili;
	}

	public String getYasadigiUlke() {
		return yasadigiUlke;
	}

	public void setYasadigiUlke(String yasadigiUlke) {
		this.yasadigiUlke = yasadigiUlke;
	}

	public char getCinsiyet() {
		return cinsiyet;
	}

	public void setCinsiyet(char cinsiyet) {
		this.cinsiyet = cinsiyet;
	}

	public double getBoy() {
		return boy;
	}

	public void setBoy(double boy) {
		this.boy = boy;
	}

	public double getKilo() {
		return kilo;
	}

	public void setKilo(double kilo) {
		this.kilo = kilo;
	}
	

}
