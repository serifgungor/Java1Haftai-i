import java.util.ArrayList;

public class Insan_deneme {

	public static void main(String[] args) {

		ArrayList<Insan> insanlar = new ArrayList<>();
		Insan insan = new Insan();
		insan.setAd("Ad");
		insan.setBoy(170);
		insan.setCinsiyet('e');
		insan.setDogumYili(1990);
		insan.setKilo(75);
		insan.setSoyad("Soyad");
		insan.setYasadigiUlke("T�rkiye Cumhuriyeti");
		
	
		//String ad, String soyad, int dogumYili, String yasadigiUlke, char cinsiyet, double boy, double kilo
		insanlar.add(insan);
		insanlar.add(new Insan("Ad2","Soyad2",1970,"T.C.",'k',160,55));
		
		for (Insan i : insanlar) {
			System.out.println("Ad: "+i.getAd());
			System.out.println("Soyad: "+i.getSoyad());
			System.out.println("----");
		}

	}

}
