
public class Ogrenci_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Set metotlar� ile nesne de�i�ken de�erlerini doldurmak
		Ogrenci ogrenci = new Ogrenci();
		ogrenci.setAdSoyad("�erif G�NG�R");
		ogrenci.setBolumAdi("Bilgisayar Programc�l���");
		ogrenci.setBolumYili(2013);
		ogrenci.setCinsiyet('e');
		ogrenci.setDogumYili(1994);
		ogrenci.setNotOrtalamasi(3.06);
		ogrenci.setOgrenciNo(2013.01);
		ogrenci.setOkulAdi("�stanbul Ticaret �niversitesi");
		
		
		System.out.println("��rencinin ad�:"+ogrenci.getAdSoyad());
		System.out.println("��rencinin okula ba�lama tarihi: "+ogrenci.getBolumYili());
		System.out.println("��rencinin not ortalamas�: "+ogrenci.getBolumYili());
		System.out.println("��rencinin okudu�u okul: "+ogrenci.getOkulAdi());
		System.out.println("��rencinin b�l�m�: "+ogrenci.getBolumAdi());
		
		//Dolu constructor seviyesinde, nesne de�i�ken de�erlerini doldurmak
		
		/*
		 String adSoyad,double ogrenciNo,char cinsiyet,int dogumYili,String okulAdi,String bolumAdi,int bolumYili,double notOrtalamasi
		 */
		
		Ogrenci ogrenci2 = new Ogrenci(
				"Ad Soyad",
				100,
				'k',
				1990,
				"�stanbul �niversitesi",
				"Bilgisayar M�hendisli�i",
				2010,
				3.30
				);
		

	}

}
