import java.util.ArrayList;
import java.util.Scanner;

public class Telefon_test {

	public static void main(String[] args) {
		int sayi = 3;
		ArrayList<Telefon> telefonListesi = new ArrayList<Telefon>();
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < sayi; i++) {
			System.out.println("L�tfen marka giriniz:");
			String marka = sc.next();
			
			System.out.println("L�tfen model giriniz:");
			String model = sc.next();
			
			System.out.println("Renk giriniz:");
			String renk = sc.next();
			
			System.out.println("��letim sistemi giriniz:");
			String os = sc.next();
			
			System.out.println("�retim y�l� giriniz:");
			int uretimYili = sc.nextInt();
			System.out.println("----");
			
			//(String marka, String model, String renk, String isletimSistemi, int uretimYili
			
			Telefon tel = new Telefon(marka,model,renk,os,uretimYili);
			telefonListesi.add(tel);
			
		}
		
		for (Telefon telefon : telefonListesi) {
			System.out.println("Telefonun markas�: "+telefon.getMarka());
			System.out.println("Telefonun modeli: "+telefon.getModel());
			System.out.println("----");
		}
		
		
		

	}

}
