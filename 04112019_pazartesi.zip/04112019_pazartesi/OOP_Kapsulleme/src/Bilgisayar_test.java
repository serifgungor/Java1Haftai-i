import java.util.ArrayList;

public class Bilgisayar_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 String islemciMarkasi, double ramBoyutu, double hddBoyutu, double ekranKartiRam, String renk,
			String isletimSistemi, int bilgisayarTipi, double fiyat
		 */
		ArrayList<Bilgisayar> bilgisayarlar = new ArrayList<>();
		bilgisayarlar.add(new Bilgisayar("AMD",16,500,4,"Beyaz","Windows10",0,5000));
		bilgisayarlar.add(new Bilgisayar("�ntel",32,1000,6,"Gri","MacOS",0,7500));
		bilgisayarlar.add(new Bilgisayar("�ntel",32,1000,6,"Beyaz","MacOS",1,17500));
		bilgisayarlar.add(new Bilgisayar("ARM",4,128,2,"Kahverengi","Linux",0,2000));
		
		
		for (Bilgisayar bilgisayar : bilgisayarlar) {
			System.out.println("Bilgisayar�n ��lemci T�r�: "+bilgisayar.getIslemciMarkasi());
			System.out.println("Bilgisayar�n ��letim Sistemi: "+bilgisayar.getIsletimSistemi());
			System.out.println("Bilgisayar�n Ram Boyutu: "+bilgisayar.getRamBoyutu());
			System.out.println("Bilgisayar�n Rengi: "+bilgisayar.getRenk());
			System.out.println("Bilgisayar�n HDD Boyutu: "+bilgisayar.getHddBoyutu());
			System.out.println("Bilgisayar�n Ekran Kart� Ram Boyutu: "+bilgisayar.getEkranKartiRam());
			System.out.println("Bilgisayar�n Fiyat�: "+bilgisayar.getFiyat());
			
			System.out.println("----");
		}
		

	}

}
