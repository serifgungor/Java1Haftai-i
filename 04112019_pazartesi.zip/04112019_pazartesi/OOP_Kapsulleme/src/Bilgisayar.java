
public class Bilgisayar {
	private String islemciMarkasi;
	private double ramBoyutu;
	private double hddBoyutu;
	private double ekranKartiRam;
	private String renk;
	private String isletimSistemi;
	private int bilgisayarTipi; //0 - laptop,1 - masa�st�
	private double fiyat;
	
	public Bilgisayar() {
		
	}

	public Bilgisayar(String islemciMarkasi, double ramBoyutu, double hddBoyutu, double ekranKartiRam, String renk,
			String isletimSistemi, int bilgisayarTipi, double fiyat) {
		this.islemciMarkasi = islemciMarkasi;
		this.ramBoyutu = ramBoyutu;
		this.hddBoyutu = hddBoyutu;
		this.ekranKartiRam = ekranKartiRam;
		this.renk = renk;
		this.isletimSistemi = isletimSistemi;
		this.bilgisayarTipi = bilgisayarTipi;
		this.fiyat = fiyat;
	}

	public String getIslemciMarkasi() {
		return islemciMarkasi;
	}

	public void setIslemciMarkasi(String islemciMarkasi) {
		this.islemciMarkasi = islemciMarkasi;
	}

	public double getRamBoyutu() {
		return ramBoyutu;
	}

	public void setRamBoyutu(double ramBoyutu) {
		this.ramBoyutu = ramBoyutu;
	}

	public double getHddBoyutu() {
		return hddBoyutu;
	}

	public void setHddBoyutu(double hddBoyutu) {
		this.hddBoyutu = hddBoyutu;
	}

	public double getEkranKartiRam() {
		return ekranKartiRam;
	}

	public void setEkranKartiRam(double ekranKartiRam) {
		this.ekranKartiRam = ekranKartiRam;
	}

	public String getRenk() {
		return renk;
	}

	public void setRenk(String renk) {
		this.renk = renk;
	}

	public String getIsletimSistemi() {
		return isletimSistemi;
	}

	public void setIsletimSistemi(String isletimSistemi) {
		this.isletimSistemi = isletimSistemi;
	}

	public int getBilgisayarTipi() {
		return bilgisayarTipi;
	}

	public void setBilgisayarTipi(int bilgisayarTipi) {
		this.bilgisayarTipi = bilgisayarTipi;
	}

	public double getFiyat() {
		return fiyat;
	}

	public void setFiyat(double fiyat) {
		this.fiyat = fiyat;
	}
	
	
	
	

}
