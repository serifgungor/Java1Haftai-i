import java.util.ArrayList;

public class Deneme {

	public static void main(String[] args) {
		
		//Nesneler aras� haberle�me �rne�i
		
		/*
		 int ogrenciNo, int ogrenciSinif, int okulaGirisYili, int dogumYili, double notOrtalamasi,
			char cinsiyet, String adSoyad, String telefonNo
		 */
		ArrayList<Ogrenci> bilgMuhOgrencileri = new ArrayList<>();
		bilgMuhOgrencileri.add(new Ogrenci(1,1,2019,2000,3.20,'k',"Ad Soyad - 1 ","+90(212)1112233"));
		bilgMuhOgrencileri.add(new Ogrenci(2,1,2013,1990,3.30,'e',"Ad Soyad - 2","+90(212)9998877"));
		bilgMuhOgrencileri.add(new Ogrenci(3,1,2013,1990,3.30,'k',"Ad Soyad - 3","+90(212)7776655"));
		bilgMuhOgrencileri.add(new Ogrenci(4,1,2013,1990,3.30,'e',"Ad Soyad - 4","+90(212)6665544"));
		
		ArrayList<Ogrenci> elkMuhOgrencileri = new ArrayList<>();
		elkMuhOgrencileri.add(new Ogrenci(5,1,2019,2000,3.20,'k',"Ad Soyad - 5 ","+90(212)1112233"));
		
		/*
		 int haftalikSaat, int kredi, String dersAdi, String ogretmenAdSoyad, String sinifAdi,
			ArrayList<Ogrenci> ogrenciler
		 */
		ArrayList<Ders> dersler = new ArrayList<>();
		dersler.add(new Ders(8,4,"Java Programlama","�erif G�NG�R","Lab09",bilgMuhOgrencileri));
		dersler.add(new Ders(8,4,"Temel Elektronik","Hoca AdSoyad","Lab01",elkMuhOgrencileri));
		
		/*
		 String bolumAdi, int kontenjanSayisi, ArrayList<Ders> dersler, ArrayList<Ogrenci> ogrenciler
		 */
		
		ArrayList<Bolum> bolumler = new ArrayList<>();
		bolumler.add(new Bolum("Bilgisayar M�hendisli�i",240,dersler,bilgMuhOgrencileri));
		bolumler.add(new Bolum("Elektrik/Elektronik M�hendisli�i",240,dersler,elkMuhOgrencileri));
		
		//String ad, String adres, ArrayList<Bolum> bolumler
		ArrayList<Kampus> kampusler = new ArrayList<>();
		kampusler.add(new Kampus("Ayaza�a Kamp�s�","Adresi",bolumler));
		
		//String ad, String ulke, String telefonNo, ArrayList<Kampus> kampusler
		Universite universite = new Universite("�stanbul Teknik �niversitesi","T�rkiye","02129996633",kampusler);
		
		/*
		 �stanbul Teknik �niversitesinin, Ayaza�a Kamp�s�n�n, Bilgisayar M�hendisli�i B�l�m�n�n Java Programlama Dersinin
		 ��rencilerini listele
		 */
		for(Ogrenci ogrenci : universite.getKampusler().get(0).getBolumler().get(0).getDersler().get(0).getOgrenciler()) {
			System.out.println("��rencinin ad�:"+ogrenci.getAdSoyad());
			System.out.println("��rencinin do�um y�l�:"+ogrenci.getDogumYili());
		}
		

	}

}
