import java.util.ArrayList;

public class Kampus {
	private String ad;
	private String adres;
	private ArrayList<Bolum> bolumler;
	
	public Kampus() {
		
	}
	public Kampus(String ad, String adres, ArrayList<Bolum> bolumler) {
		super();
		this.ad = ad;
		this.adres = adres;
		this.bolumler = bolumler;
	}
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getAdres() {
		return adres;
	}
	public void setAdres(String adres) {
		this.adres = adres;
	}
	public ArrayList<Bolum> getBolumler() {
		return bolumler;
	}
	public void setBolumler(ArrayList<Bolum> bolumler) {
		this.bolumler = bolumler;
	}
	
	
	
}
