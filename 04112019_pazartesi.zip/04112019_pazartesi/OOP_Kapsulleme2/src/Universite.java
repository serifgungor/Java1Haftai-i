import java.util.ArrayList;

public class Universite {
	private String ad;
	private String ulke;
	private String telefonNo;
	private ArrayList<Kampus> kampusler;
	
	public Universite() {
		
	}

	public Universite(String ad, String ulke, String telefonNo, ArrayList<Kampus> kampusler) {
		this.ad = ad;
		this.ulke = ulke;
		this.telefonNo = telefonNo;
		this.kampusler = kampusler;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getUlke() {
		return ulke;
	}

	public void setUlke(String ulke) {
		this.ulke = ulke;
	}

	public String getTelefonNo() {
		return telefonNo;
	}

	public void setTelefonNo(String telefonNo) {
		this.telefonNo = telefonNo;
	}

	public ArrayList<Kampus> getKampusler() {
		return kampusler;
	}

	public void setKampusler(ArrayList<Kampus> kampusler) {
		this.kampusler = kampusler;
	}

	
	
}
