import java.util.Deque;
import java.util.LinkedList;

public class Dequeue_Ornek1 {

	public static void main(String[] args) {
		
		Deque<Integer> sayilar = new LinkedList<>();
		
		sayilar.offer(10);
		sayilar.offer(50);
		sayilar.offer(40);
		sayilar.offer(150);
		
		//sayilar.poll(); //�lk de�eri sildik
		//System.out.println(sayilar.peek()); //�lk de�eri �a��rd�k
		
		for (int i=0; i<4; i++) {
			System.out.println(sayilar.peekFirst());
			sayilar.poll();
		}
		
	}

}
