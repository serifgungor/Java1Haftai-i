import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek3 {

	public static void main(String[] args) {
		
		
		ArrayList<Integer> sayilar = new ArrayList<>();
		System.out.println("Ka� adet say� gireceksiniz ?");
		Scanner sc = new Scanner(System.in);
		int sayi = sc.nextInt();
		
		for (int i = 0; i < sayi; i++) {
			System.out.println("Say� giriniz:");
			sayilar.add(sc.nextInt());
		}
		System.out.println("0 ile "+(sayi-1)+" aras� say� giriniz");
		int girilenSayi = sc.nextInt();
		sayilar.remove(girilenSayi);
		
		for (int i = 0; i < sayilar.size(); i++) {
			System.out.println(sayilar.get(i));
		}
		
		

	}

}
