import java.util.Scanner;
import java.util.Vector;

public class Vector_Ornek3 {

	public static void main(String[] args) {
		Vector<String> elemanlar = new Vector<>();
		Scanner sc = new Scanner(System.in);
		
		for (int i = 0; i < 5; i++) {
			System.out.println("L�tfen de�er giriniz");
			elemanlar.add(sc.next());
		}
		
		

	}

}
