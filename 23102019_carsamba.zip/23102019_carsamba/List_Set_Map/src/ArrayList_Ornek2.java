import java.util.ArrayList;
import java.util.Scanner;

public class ArrayList_Ornek2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ka� adet kelime gireceksiniz ?");
		int sayi = sc.nextInt();
		
		ArrayList<String> elemanlar = new ArrayList<>();
		
		//D��ar�dan de�erleri istemek i�in
		for (int i = 0; i < sayi; i++) {
			System.out.println((i+1)+" eleman� giriniz.");
			elemanlar.add(sc.next());
		}
		
		for (int i = 0; i < elemanlar.size(); i++) {
			System.out.println(elemanlar.get(i));
		}
		

	}

}
