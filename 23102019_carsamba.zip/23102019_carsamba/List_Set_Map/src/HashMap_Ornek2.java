import java.util.HashMap;
import java.util.Scanner;

public class HashMap_Ornek2 {

	public static void main(String[] args) {
		/*
		 D��ar�dan n adet anahtar ve de�er al�p hashmap i�erisinde saklay�n�z.
		 hashmap i�erisinde daha sonra anahtar belirtip de�erini yazd�r�n�z.
		 E�er aranan key de�eri yoksa bulunamad� yazs�n.
		 */

		Scanner sc = new Scanner(System.in);
		System.out.println("Ka� adet de�er gireceksiniz ?");
		int n = sc.nextInt();
		
		HashMap<String, String> degerler = new HashMap<String,String>();
		
		for (int i = 0; i < n; i++) {
			System.out.println("Anahtar giriniz");
			String anahtar = sc.next();
			System.out.println("De�er giriniz");
			String deger = sc.next();
			degerler.put(anahtar, deger);
		}
		
		System.out.println("De�erini ��renmek i�in bir anahtar giriniz");
		String anahtar = sc.next();
		if(degerler.containsKey(anahtar)) {
			System.out.println("Anahtara ait de�er: "+degerler.get(anahtar));
		}else {
			System.out.println("B�yle bir anahtar yok !");
		}
		
		
	}

}
