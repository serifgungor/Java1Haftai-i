import java.util.HashMap;
import java.util.Scanner;

public class HashMap_Ornek3 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		HashMap<Integer,String> ilceler = new HashMap<>();
		
		for (int i = 0; i < 5; i++) {
			System.out.println("Posta kodu yaz�n�z");
			int postaKodu = sc.nextInt();
			System.out.println("�l�e ad� giriniz");
			String ilceAdi = sc.next();
			ilceler.put(postaKodu, ilceAdi);
		}
		
		
		for (String ilceAdi : ilceler.values()) {
			System.out.println(ilceAdi);
		}
		
		for (int postaKodu : ilceler.keySet()) {
			System.out.println(postaKodu);
		}
		

	}

}
