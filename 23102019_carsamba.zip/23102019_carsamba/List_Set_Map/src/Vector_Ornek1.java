import java.util.Vector;

public class Vector_Ornek1 {

	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>(1);
		vector.addElement("�erif");
		vector.addElement("istanbul");
		vector.addElement("Yaz�l�m Geli�tiricisi");
		
		for (String string : vector) {
			System.out.println(string);
		}
		
		System.out.println("Capacity: "+vector.capacity());
		
		System.out.println("Size: "+vector.size());
		
		/*
		 addElement - veri eklemek i�in kullan�l�r.
		 capacity - vector'�n kapasitesini belirtir. E�er kapasite yetmezse, kapasite y�kseltilir.
		 clear - de�erleri temizler
		 contains - Listede de�er aramak i�in kullan�l�r.
		 get - indisini bildi�imiz de�eri �a��rmak i�in kullan�l�r.
		 indexOf - indisini bildi�imiz de�erin indisini �a��rmak i�in kullan�l�r (ilk bulunan)
		 lastIndexOf - ismini bildi�imiz de�erin indisini �a��rmak i�in kullan�l�r. (son bulunan)
		 removeAllElements - t�m elemanlar� silmek i�in kullan�l�r.
		 set - var olan de�eri de�i�tirmek i�in kullan�l�r.
		 remove - belirtilen indisteki/isimdeki eleman� silmek i�in kullan�l�r.
		 size - vector'�n eleman say�s�n� d�ner.
		 */
		
		

	}

}
