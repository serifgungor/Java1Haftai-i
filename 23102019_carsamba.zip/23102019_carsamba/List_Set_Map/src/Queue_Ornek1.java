import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Queue_Ornek1 {

	public static void main(String[] args) {
		
		/*
		 add - belirtilen de�eri kuyru�a ekler. ekleyemezse hata verir.
		 offer - belirtilen de�eri kuyru�a ekler. ekleyemezse null d�ner
		 poll - Kuyru�un en ba��ndaki eleman� kuyruktan ��kar�r.
		 peek - Kuyrukta s�radaki elemana eri�mek i�in kullan�l�r
		 */
		
		//First In First Out - FIFO
		
		Queue<String> kuyruk = new LinkedList<>();
		
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 2; i++) {
			System.out.println("Kuyru�a eklenecek de�eri giriniz\n---");
			String str = sc.next();
			if(kuyruk.add(str)) {
				System.out.println("De�er kuyru�a eklendi: "+str+"\n");
			}
		}
		kuyruk.poll(); // �lk s�radaki de�eri sildik.
		
		for (String string : kuyruk) { // T�m de�erleri listeledik.
			System.out.println(string);
		}
		
		

	}

}
