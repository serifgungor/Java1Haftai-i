import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Veritabani_deneme extends Veritabani {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		baglan("Z:/deneme.db");
		
		String islem = null;
		while (true) {
			System.out.println("L�tfen i�lem giriniz (tablodakiverisayisi,tablolarigetir,listele,ekle,sil,g�ncelle,t�m�n�sil)");
			islem = sc.next();
			if("listele".equals(islem)) {
				try {
					ResultSet rs = verileriListele("select * from Rehber");
					//resultset'den d�nen t�m sat�r de�erlerini yakalayabilmek i�in
					while(rs.next()) {//yeni bir sat�r verisi varsa
						System.out.println("Rehber ID: "+rs.getInt("id"));
						System.out.println("Telefon numaras�: "+rs.getString("telefon_no"));
						System.out.println("Ad: "+rs.getString("ad"));
						System.out.println("Soyad: "+rs.getString("soyad"));
						System.out.println("Adres: "+rs.getString("adres"));
						System.out.println("Email: "+rs.getString("email"));
						System.out.println("-----");
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}else if("ekle".equals(islem)) {
				try {
					System.out.println("L�tfen telefon numaras� giriniz");
					String telefon = sc.next();
					System.out.println("L�tfen ad giriniz");
					String ad = sc.next();
					System.out.println("L�tfen soyad giriniz");
					String soyad = sc.next();
					System.out.println("L�tfen adres giriniz");
					String adres = sc.next();
					System.out.println("L�tfen email giriniz");
					String email = sc.next();
					veriEkle(
							"Rehber",
							"telefon_no,ad,soyad,adres,email",
							"'"+telefon+"','"+ad+"','"+soyad+"','"+adres+"','"+email+"'"
							);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}else if("sil".equals(islem)) {
				System.out.println("L�tfen tablo ismi belirtiniz");
				String tablo = sc.next();
				System.out.println("L�tfen �art belirtiniz (�rn: id=1)");
				String sart = sc.next();
				try {
					veriSil(tablo, sart);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}else if("g�ncelle".equals(islem)) {
				try {
					veriGuncelle("Rehber", "ad='ismek'", "id=11");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}else if("t�m�n�sil".equals(islem)) {
				System.out.println("L�tfen bir tablo ad� belirtiniz");
				String tablo = sc.next();
				try {
					verilerinTumunuSil(tablo);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}else if("tablolarigetir".equals(islem)) {
				try {
					for (String tabloAdi : tabloAdlariniListele_SQLite()) {
						System.out.println(tabloAdi);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}else if("tablodakiverisayisi".equals(islem)) {
				System.out.println("L�tfen bir tablo ad� giriniz");
				String tabloadi = sc.next();
				try {
					int sayi = tablodakiVeriSayisi(tabloadi);
					System.out.println("Tablodaki veri say�s�: "+sayi);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		/*
		if(baglan("Z:/deneme.db")) {
			System.out.println("Veritaban�na ba�ar�l� �ekilde ba�lan�ld�");
		}else {
			System.out.println("Veritaban�na ba�lan�rken bir sorun olu�tu.");
		}*/
	
		
		
		
	}

}
