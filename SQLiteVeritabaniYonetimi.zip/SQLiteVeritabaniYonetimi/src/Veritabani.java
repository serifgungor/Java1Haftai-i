import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;  

public class Veritabani {
	static Connection conn = null;
	static Statement st = null;
	// Veritaban� sorgular� g�nderebilmek i�in statement s�n�f�n� kullan�r�z.

	
	public static boolean baglan(String dbLokasyonu) {  
		boolean response = false;
        try {  
            // db parameters  
            String url = "jdbc:sqlite:"+dbLokasyonu;  
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(url); 
            /*conn nesnesinin createStatement metodu Statement nesnesinin 
             veritaban� ba�lant�s� yapabilmesi i�in driver'a ba�lanmas� i�lemini
             yapar.
             */
            st = conn.createStatement();
            //System.out.println("Veritaban�na ba�lant� sa�land�");  
            response = true;
        } catch (SQLException e) {  
        	response = false;
        	System.out.println("Veritaban�na ba�lant� sa�lanamad�: ("+e.getMessage()+")");
        }catch(ClassNotFoundException e) {
        	response = false;
        	System.out.println("Veritaban�na ba�lant� sa�lanamad�: ("+e.getMessage()+")");
        }
        return response;
    } 
	
	public static void baglantiyiKapat() {
		try {  
            if (conn != null) {  //Connection nesnesi tan�ms�z de�il ise,
                conn.close();  //Veritaban� ba�lant�s�n� kapat
            } 
            if(st != null) {
            	st.close();
            }
        } catch (SQLException ex) {  //Veritaban� hatas� var ise
            System.out.println(ex.getMessage());  //Hatay� g�ster
        }
	}
	
	public static ResultSet verileriListele(String sorgu) throws SQLException {
		ResultSet rs = st.executeQuery(sorgu);
		return rs;
		/*
		ResultSet s�n�f�, select sorgusundan d�nen t�m sat�r verilerini okuyup
		saklayabilmek i�in kullanabilece�imiz bir s�n�ft�r.
		 */
	}
	
	public static ResultSet tabloyuListele(String tablo) throws SQLException {
		ResultSet rs = st.executeQuery("select * from "+tablo);
		return rs;
	}
	
	public static int tablodakiVeriSayisi(String tablo) throws SQLException{
		ResultSet rs = st.executeQuery("SELECT COUNT(*) as sayi FROM "+tablo);
		rs.next();
		return rs.getInt("sayi");
	}
	
	public static ArrayList<String> tabloAdlariniListele_SQLite() throws SQLException{
		ArrayList<String> tablolar = new ArrayList<>();
		ResultSet rs = st.executeQuery("SELECT name FROM sqlite_master WHERE type = 'table'");
		while (rs.next()) {
			tablolar.add(rs.getString("name"));
		}
		return tablolar;
	}
	
	public static void veriEkle(String tablo,String kolonlar,String degerler) throws SQLException {
		/*
		 Veri eklemek, silmek ve g�ncellemek i�in statement s�nf�n�n executeUpdate
		 metodunu kullanaca��z.
		 */
		st.executeUpdate("insert into "+tablo+" ("+kolonlar+") values ("+degerler+")");
	}
	
	public static void veriSil(String tablo,String sart) throws SQLException{
		st.executeUpdate("delete from "+tablo+" where "+sart);
	}
	
	public static void verilerinTumunuSil(String tablo) throws SQLException{
		st.executeUpdate("delete from "+tablo);
	}
	
	public static void veriGuncelle(String tablo,String kolonDegerleri,String sart) throws SQLException {
		st.executeUpdate("update "+tablo+" set "+kolonDegerleri+" where "+sart);
	}

}
