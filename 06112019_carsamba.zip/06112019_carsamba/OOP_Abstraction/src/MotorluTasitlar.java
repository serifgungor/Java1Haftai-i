
public class MotorluTasitlar extends Araba {

}
