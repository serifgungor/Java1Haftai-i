
public class Araba_deneme {

	public static void main(String[] args) {
		Araba araba = new Araba();
		
		MotorluTasitlar mt = new MotorluTasitlar();
		mt.arabaPlaka("34 AA 1234");
		
		Araba a = new MotorluTasitlar();
		a.arabaPlaka("01 AA 1234");

	}

}
