
public class Telefon {

}
