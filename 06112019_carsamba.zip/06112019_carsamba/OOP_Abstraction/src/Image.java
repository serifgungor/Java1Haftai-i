
public class Image extends View {

	@Override
	public void onClick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onClickListener(String str) {
		// TODO Auto-generated method stub
		
	}

}
