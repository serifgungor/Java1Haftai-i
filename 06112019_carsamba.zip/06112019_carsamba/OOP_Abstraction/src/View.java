
public abstract class View {
	public abstract void onClick();
	public abstract void onClickListener(String str);
}
