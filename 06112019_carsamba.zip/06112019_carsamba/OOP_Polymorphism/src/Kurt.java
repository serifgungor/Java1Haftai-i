
public interface Kurt {
	
	public void ulu();
	public void kos();
	public void saldir();
	public void penceAt();

}
