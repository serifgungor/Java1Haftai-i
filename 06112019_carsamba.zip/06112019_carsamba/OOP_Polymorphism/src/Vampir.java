
public class Vampir extends Insan implements Yarasa {

	@Override
	public void uc() {
		System.out.println("U�tum");		
	}

	@Override
	public void isir() {
		System.out.println("Is�rd�m");
	}

}
