
public class Vampir_deneme {

	public static void main(String[] args) {
		Vampir vampir = new Vampir();
		vampir.isir();
		vampir.konus();
		vampir.sarkiSoyle();
		vampir.uc();
		vampir.yuru();

	}

}
