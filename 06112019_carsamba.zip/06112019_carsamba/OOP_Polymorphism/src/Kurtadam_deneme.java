
public class Kurtadam_deneme {

	public static void main(String[] args) {
		
		KurtAdam kurtAdam = new KurtAdam();
		kurtAdam.agla();
		kurtAdam.dusun();
		kurtAdam.giyin();
		kurtAdam.konus();
		kurtAdam.kos();
		kurtAdam.penceAt();
		kurtAdam.saldir();
		kurtAdam.ulu();
		kurtAdam.yuru();

	}

}
