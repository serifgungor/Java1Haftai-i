
public class KurtAdam extends Adam implements Kurt {

	@Override
	public void ulu() {
		// TODO Auto-generated method stub
		System.out.println("Uludu");
	}

	@Override
	public void kos() {
		// TODO Auto-generated method stub
		System.out.println("Ko�tu");
	}

	@Override
	public void saldir() {
		// TODO Auto-generated method stub
		System.out.println("Sald�rd�");
	}

	@Override
	public void penceAt() {
		// TODO Auto-generated method stub
		System.out.println("Pen�e att�");
	}

}
