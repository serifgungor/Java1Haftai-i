
public class Insan_deneme {

	public static void main(String[] args) {
		

		Adem adem = new Adem();
		adem.avla();
		adem.konus();
		adem.nefesAl();
		adem.uyan();
		adem.uyu();
		adem.yemekYe();
		System.out.println("-----");
		Insan insan = new Insan();
		insan.arabaSur();
		insan.iseGit();
		insan.kitapOku();
		insan.sarkiSoyle();
		insan.avla();
		insan.konus();
		insan.uyu();
		insan.uyan();
		
		

	}

}
