
public class Egitim_deneme {

	public static void main(String[] args) {
		Egitim egitim = new Egitim();
		egitim.materyaller();
		egitim.mufredat();
		System.out.println("---");
		
		Ogrenci ogrenci = new Ogrenci();
		ogrenci.dersler();
		ogrenci.sinif(2);
		ogrenci.materyaller();
		ogrenci.mufredat();
		System.out.println("---");
		
		Ogretmen ogretmen = new Ogretmen();
		ogretmen.adSoyad("Ad Soyad");
		ogretmen.dersler();
		ogretmen.mufredat();
		ogretmen.materyaller();

	}

}
