import java.util.ArrayList;

public class MotorluTasit_deneme {

	public static void main(String[] args) {
		ArrayList<MotorluTasitlar> tasitlar = new ArrayList<MotorluTasitlar>();
		
		//String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,

		tasitlar.add(new Araba("Mercedes","K�rm�z�",4,1,2,2000));
		tasitlar.add(new Kamyon("VOLVO","Beyaz",6,0,0,1500));
		tasitlar.add(new Tir("Scana","Beyaz",8,0,1,3000));
		tasitlar.add(new SUV("Land Rover","Siyah",4,2,2,2000));
		
		for (MotorluTasitlar motorluTasitlar : tasitlar) {
			
			System.out.println("Marka: "+motorluTasitlar.getMarka());
			System.out.println("Renk: "+motorluTasitlar.getRenk());
			System.out.println("Tekerlek Say�s�: "+motorluTasitlar.getTekerlekSayisi());
			System.out.println("Vites T�r�: "+motorluTasitlar.getVitesTuru());
			System.out.println("Yak�t T�r�: "+motorluTasitlar.getYakitTuru());
			System.out.println("Beygir G�c�: "+motorluTasitlar.getBeygirGucu());
			motorluTasitlar.tur(); //Metot Override i�lemi yapt�k
			
			
			if(motorluTasitlar instanceof Araba) {
				Araba araba = (Araba)motorluTasitlar;
				araba.yolcuSayisi();
			}
			
			System.out.println("---");
		}
		
		/*
		 Bir ArrayList'e s�n�f tipleri farkl� olmas�na ra�men de�erleri ekleyebiliriz. 
		 Eklemek istedi�imiz nesnelerin(s�n�flar�n) miras al�nan �st s�n�f� �retti�imiz ArrayList tipindeyse
		 de�erleri eklememize olanak tan�n�r.
		 
		 */

	}

}
