
public class Egitim {
	public void mufredat() {
		System.out.println("M�fredat");
	}
	public void materyaller() {
		System.out.println("Materyaller");
	}
}
