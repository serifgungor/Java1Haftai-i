
public class Panter extends Kedigil {
	
	public void agacaCik() {
		System.out.println("Panter a�aca ��kt�");
	}

}
