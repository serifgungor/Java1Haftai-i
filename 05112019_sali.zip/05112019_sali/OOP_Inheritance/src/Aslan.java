
public class Aslan extends Kedigil {
	
	public void vahsiOl() {
		System.out.println("Aslan vah�i oldu");
	}
	public void sesCikar() {
		System.out.println("Aslan ses ��kard� - waaw !");
	}
	public void kosmaHizi(int hiz) {
		System.out.println("Aslan�n ko�ma h�z�: "+hiz);
	}

}
