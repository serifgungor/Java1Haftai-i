
public class Araba extends MotorluTasitlar {
	
	public Araba(String marka, String renk, int tekerlekSayisi, int yakitTuru, int vitesTuru,
			double beygirGucu) {
		super(marka,renk,tekerlekSayisi,yakitTuru,vitesTuru,beygirGucu);
	}
	
	public void tur() {
		System.out.println("Araba");
	}
	
	public void yolcuSayisi() {
		System.out.println("Yolcu say�s� 5");
	}
	
}
