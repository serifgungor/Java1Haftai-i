
public class Kedi extends Kedigil {
	
	public void uyu() {
		System.out.println("Kedi uyudu");
	}
	
	public void evcilOl() {
		System.out.println("Kedi evcil oldu");
	}
	
	public void sesCikar() {
		System.out.println("Kedi ses ��kard� - Miyavv !");
	}
	
	public void kosmaHizi(int hiz) {
		System.out.println("Kedinin ko�ma h�z�: "+hiz);
	}

}
