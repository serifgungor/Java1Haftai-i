
public class Ornek10 {
	
	public double hesapla(double sayi1, double sayi2, String islem) {
		double sonuc = 0;
		switch (islem) {
			case "topla":
				sonuc = sayi1+sayi2;
				break;
			case "��kar":
				sonuc = sayi1-sayi2;
				break;
			case "�arp":
				sonuc = sayi1*sayi2;
				break;
			case "b�l":
				sonuc = sayi1/sayi2;
				break;
			default:
				sonuc = -1;
				break;
		}
		return sonuc;
	}

	public static void main(String[] args) {
		// hesaplama yapan metot �retiniz.
		Ornek10 hesaplama = new Ornek10();
		double sonuc = hesaplama.hesapla(10, 2.5, "�arp");
		System.out.println(sonuc);
		sonuc = hesaplama.hesapla(10, 125.50, "topla");
		System.out.println(sonuc);
		sonuc = hesaplama.hesapla(250, 25, "b�l");
		System.out.println(sonuc);

	}

}
