import java.util.Scanner;

public class Ornek13 {
	
	public String notHesapla(double vizePuan,double finalPuan) {
		String str = null;
		
		double ortalama = (vizePuan*0.4)+(finalPuan*0.6);
		
		if(ortalama>=0 && ortalama<=10) {
			str = "FF";
		}else if(ortalama>10 && ortalama<=20) {
			str = "FD";
		}else if(ortalama>21 && ortalama<=30) {
			str = "DD";
		}else if(ortalama>31 && ortalama<=40) {
			str = "DC";
		}else if(ortalama>41 && ortalama<=50) {
			str = "CC";
		}else if(ortalama>51 && ortalama<=60) {
			str = "CB";
		}else if(ortalama>61 && ortalama<=70) {
			str = "BB";
		}else if(ortalama>71 && ortalama<=80) {
			str = "BA";
		}else if(ortalama>81) {
			str = "AA";
		}
		
		return str;
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Vize notunuzu giriniz");
		double vizeNotu = sc.nextDouble();
		
		System.out.println("Final notunuzu giriniz");
		double finalNotu = sc.nextDouble();
		
		Ornek13 o = new Ornek13();
		String sonuc = o.notHesapla(vizeNotu, finalNotu);
		if("FF".equals(sonuc)) {
			System.out.println("Kald�n�z, l�tfen seneye tekrar deneyin !");
		}else if("FD".equals(sonuc)) {
			System.out.println("Kald�n�z, l�tfen seneye tekrar deneyin !");
		}else {
			System.out.println("Tebrikler dersi ge�tiniz. Notunuz: "+sonuc);
		}
		
		
		/*
�niversite s�nav notuna g�re puan�n� hesaplayan metot yaz�n�z

Metot geri d�n�� tipi string olsun.
Metot arg�manlar�:  double VizePuan, double FinalPuan

AA - 4
BA - 3.5
BB - 3
CB - 2.5
CC - 2
DC - 1.5
DD - 1
FD - 0.5
FF - 0
 */

	}

}
