import java.util.Scanner;

public class Ornek15 {
	
	public int harfleriSay(char[] ch, char arananKarakter) {
		int sonuc =0;
		for (int i = 0; i < ch.length; i++) {
			if(ch[i]==arananKarakter) {
				sonuc++;
			}
		}
		return sonuc;
	}
	

	public static void main(String[] args) {
		/*
		 D��ar�dan 5 adet string isteyip diziye at�n. �lgili stringlerin ilk harfini bir char[] de saklay�n.
		 char[] i�inde olan elemanlar�n hepsini bir string'de birle�tirin.
		 birle�tirdi�iniz string i�erisinde 1 karakter aray�n.
		 */
		
		char[] chDizi = new char[5];
		Scanner sc = new Scanner(System.in);
		
		//D��ar�dan 5 adet string al�p, ilk karakterlerini char[] i�erisinde saklad�k.
		for (int i = 0; i < chDizi.length; i++) {
			System.out.println("L�tfen kelime giriniz");
			chDizi[i] = sc.next().charAt(0);
		}
		
		//char[] i�erisindeki her karakteri yeniMetin'in i�erisinde birle�tirdik.
		String yeniMetin = "";
		for (int i = 0; i < chDizi.length; i++) {
			yeniMetin += chDizi[i];
		}
		System.out.println("�retilen yeni metin: "+yeniMetin);
		
		//D��ar�dan 1 karakter isteyip, �retilen yeni string'de karakterin say�s�n� bulduk.
		Ornek15 o = new Ornek15();
		System.out.println("Bir karakter giriniz:");
		char ch = sc.next().charAt(0);
		int sayi = o.harfleriSay(chDizi, ch);
		System.out.println("Karakterin say�s�: "+sayi);
		
		

	}

}
