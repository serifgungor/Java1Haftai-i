import java.util.Scanner;

public class Ornek14 {
	
	//Belirtti�imiz stringler i�erisindeki ilgili karakterin say�s�n� bulma
	public int karakterSayisi(String[] str,char harf) {
		int sonuc =0;
		//String dizisi elemanlar�n� d�nmek i�in kullan�l�r
		for (int i = 0; i < str.length; i++) {
			//ilgili string dizisi eleman�n�n karakter uzunlu�u kadar d�ns�n
			for (int j = 0; j < str[i].length(); j++) {
				if(str[i].charAt(j)==Character.toUpperCase(harf) || str[i].charAt(j) == Character.toLowerCase(harf)) {
					sonuc++;
				}
			}
		}
		return sonuc;
	}
	
	//Belirtti�imiz stringin i�erisindeki ilgili karakterin say�s�n� bulma
	public int karakterSayisi(String str,char harf) {
		int sonuc = 0;
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i)==Character.toUpperCase(harf) || str.charAt(i)==Character.toLowerCase(harf)) {
				sonuc++;
			}
		}
		return sonuc;
	}
	
	
	public static void main(String[] args) {
		// Belirlenen karakterin say�s�n� bulan metot �retme �rne�i
		
		//D��ar�dan 5 yaz� girip, bunlar�n i�inde ka� adet belirtti�imiz karakterin oldu�unu bulma
		
		Scanner sc = new Scanner(System.in);
		String[] dizi = new String[5];
		
		for (int i = 0; i < 5; i++) {
			System.out.println("L�tfen bir metin giriniz");
			dizi[i] = sc.nextLine();
		}
		
		Ornek14 karakter = new Ornek14();
		System.out.println("Karakter giriniz");
		char harf = sc.next().charAt(0);
		int toplamSayi = karakter.karakterSayisi(dizi, harf);
		System.out.println("Dizi elemanlar�nda toplam: "+toplamSayi+" adet "+harf+" bulunmaktad�r.");
		
		
		

	}

}
