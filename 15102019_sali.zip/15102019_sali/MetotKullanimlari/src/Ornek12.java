
public class Ornek12 {

	public String buyukluKucukluYaz(String yazi) {
		String geciciDeger = "";
		for (int i = 0; i < yazi.length(); i++) {
			String str  = ""+yazi.charAt(i);
			if(i%2==0) {
				geciciDeger+=str.toLowerCase();
			}else {
				geciciDeger+=str.toUpperCase();
			}
		}
		return geciciDeger;
	}
	
	public static void main(String[] args) {
		Ornek12 yazdir = new Ornek12();
		String yazi = yazdir.buyukluKucukluYaz("java programlama 1");
		System.out.println(yazi);

	}

}






