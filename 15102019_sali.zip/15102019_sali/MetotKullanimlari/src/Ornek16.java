
public class Ornek16 {
	
	public String terstenYazdir(String yazi) {
		String gecici = "";
		for (int i = yazi.length()-1; i >= 0; i--) {
			gecici += yazi.charAt(i);
		}
		return gecici;
	}

	public static void main(String[] args) {
		// D��ar�dan girilen bir kelimeyi tersten yazd�ran metot �retiniz.
		
		String yazi = "�ER�F G�NG�R";
		Ornek16 o = new Ornek16();
		System.out.println(o.terstenYazdir(yazi));

	}

}
