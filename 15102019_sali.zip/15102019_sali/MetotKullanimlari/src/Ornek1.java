
public class Ornek1 {
	
	public void selamVer() {
		System.out.println("Selamlar !");
	}
	
	public int topla(int sayi1,int sayi2) {
		int toplam = sayi1+sayi2;
		return toplam;
	}
	public int cikar(int sayi1,int sayi2) {
		int toplam = sayi1-sayi2;
		return toplam;
	}
	public int carp(int sayi1,int sayi2) {
		int toplam = sayi1*sayi2;
		return toplam;
	}
	public int bol(int sayi1,int sayi2) {
		int toplam = sayi1/sayi2;
		return toplam;
	}
	public static void main(String[] args) {
		
		/*
		 Metot Nedir ?
		 
		 - Belirli i�lemleri ger�ekle�tiren kod bloklar�d�r.
		 - Metotlar�n geri d�n�� tipleri bulunabildi�i gibi, bulunmayadabilir.
		 - E�er bir metot geri de�er d�nd�rmeyecek ise tip olan k�sma void yaz�l�r.
		 - void harici bir veri tipi belirtirsek, belirtti�imiz o tipte veri d�nd�rmek zorunday�z.
		 -- Metot geri d�n�� tipi void de�il ise, return keyword'� metodun en alt sat�r�nda yaz�lmak zorundad�r.
		 -- return kelimesinden sonra alt sat�rlarda asla kod yaz�lamaz.
		 -- bir metotta return kelimesi sadece 1 defa kullan�labilir.
		
		 */
		Ornek1 o = new Ornek1(); // Bir nesne �rettik. newleme yapmak
		o.selamVer();
		
		int topla = o.topla(5, 10);
		int cikar = o.cikar(5, 10);
		int carp = o.carp(5,10);
		int bol = o.bol(10,2);
		System.out.println(topla);
		System.out.println(cikar);
		System.out.println(carp);
		System.out.println(bol);

	}

}
