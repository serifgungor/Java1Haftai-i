
public class Ornek3 {

	public static void main(String[] args) {
		
		/*
		 Berirlenen ba�lang�� ve biti� indisleri aras�ndaki de�erlerin
		 okunmas�n� sa�layan string metodudur.
		 */
		
		String sehir = "YUNAN�STANBULGAR�STAN";
		
		String istanbul = sehir.substring(5,13);
		// 6. ve 14. karakterler aras�ndaki t�m karakterleri birle�tirip
		// yeni bir kelime elde ettik.

		System.out.println(istanbul);
		

	}

}
