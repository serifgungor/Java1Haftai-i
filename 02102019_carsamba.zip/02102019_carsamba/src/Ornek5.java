
public class Ornek5 {

	public static void main(String[] args) {
		String sehir = "�stanbul";
		String baskent = "ankara";
		
		if("istanbul".equals(sehir)) {
			System.out.println("�ehir istanbul'dur");
		}else {
			System.out.println("�ehir istanbul de�ildir.");
		}
		
		if("ANKARA".equalsIgnoreCase(baskent)) {
			System.out.println("Ba�kent ankara'ya e�ittir.");
		}else {
			System.out.println("Ba�kent ankara'ya e�it de�ildir.");
		}
	}

}
