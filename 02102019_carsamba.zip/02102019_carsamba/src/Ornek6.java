
public class Ornek6 {

	public static void main(String[] args) {
		String site = "www.serifgungor.com";
		if(site.startsWith("www.")) {
			System.out.println("www. ile ba�lamaktad�r.");
		}else {
			System.out.println("www. ile ba�lamamaktad�r.");
		}
		
		if(site.endsWith(".com")) {
			System.out.println(".com ile bitmektedir.");
		}else {
			System.out.println(".com ile bitmemektedir.");
		}

	}

}
