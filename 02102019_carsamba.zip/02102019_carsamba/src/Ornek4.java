
public class Ornek4 {

	public static void main(String[] args) {
		String yazi = "NE MUTLU T�RK'�M D�YENE !";
		
		if(yazi.contains("T�RK")) {
			System.out.println("Metinde T�RK kelimesi ge�mektedir.");
		}else {
			System.out.println("Metinde T�RK kelimesi ge�memektedir.");
		}

		
		
	}

}
