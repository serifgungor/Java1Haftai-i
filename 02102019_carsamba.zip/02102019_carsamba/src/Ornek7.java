
public class Ornek7 {

	public static void main(String[] args) {
		String turkceEnUzunKelime = "muvaffakiyetsizle�tiricile�tiriveremeyebileceklerimizdenmi�sinizcesine";
		System.out.println("Karakter uzunlu�u: "+turkceEnUzunKelime.length());
		
		String okul = "�smek Fatih Bili�im Okulu";
		System.out.println("Karakter uzunlu�u: "+okul.length());

	}

}
