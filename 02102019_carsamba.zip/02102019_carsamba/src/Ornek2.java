
public class Ornek2 {

	public static void main(String[] args) {
		String okul = "�smek Fatih Bili�im Okulu";
		
		System.out.println(okul.toLowerCase());
		System.out.println(okul.toUpperCase());
		System.out.println(okul);
		okul = okul.toUpperCase();
		System.out.println(okul);

	}	

}
