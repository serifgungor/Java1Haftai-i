
public class Ornek4_Math {

	public static void main(String[] args) {
		// Math s�n�f� metotlar�
		
		double pi = Math.PI; 
		System.out.println("PI Say�s�: "+pi);
		
		double e = Math.E;
		System.out.println("EULER Say�s�: "+e);
		
		double min = Math.min(90, 75);
		System.out.println("En k���k say�: "+min);
		
		double max = Math.max(1670, 10);
		System.out.println("En b�y�k say�: "+max);
		
		double rastgele =  Math.random();
		System.out.println("Rastgele say�: "+rastgele);
		
		double floor = Math.floor(150.70);
		System.out.println(floor);
		//K�s�rattan sonras�n� s�f�ra indirir
		
		double mutlakDeger = Math.abs(50.7);
		System.out.println("Mutlak de�er: "+mutlakDeger);
		
		double kareKok = Math.sqrt(10.8);
		System.out.println("Karek�k: "+kareKok);
		
		double round = Math.round(45.2);
		System.out.println("Round ile yuvarlama: "+round);
		//0.50 �ncesini alta, 0.50 sonras�n� �ste yuvarlar
		
		
		
		

	}

}
