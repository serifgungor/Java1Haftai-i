import java.util.Random;
import java.util.Scanner;

public class Ornek3_Random {

	public static void main(String[] args) {
		// SAYI TAHM�N OYUNU
		
		Random rastgele = new Random();
		int gecici = rastgele.nextInt(5);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Bir say� giriniz (0-5 aral���nda)");
		int sayi = sc.nextInt();
		
		if(sayi==gecici) {
			System.out.println("Tebrikler, say�y� buldunuz.");
			System.out.println("Say�: "+gecici);
		}else if(sayi>gecici) {
			System.out.println("Tahmin etti�iniz say� b�y�kt�r.");
			System.out.println("Bilmen gereken: "+gecici);
			System.out.println("S�yledi�iniz: "+sayi);
		}else if(gecici>sayi) {
			System.out.println("Tahmin etti�iniz say� k���kt�r.");
			System.out.println("Bilmen gereken: "+gecici);
			System.out.println("S�yledi�iniz: "+sayi);
		}
		

	}

}
