import java.util.Random;

public class Ornek2_Random {

	public static int sayiUret(int maxInt) {
		Random rnd = new Random();
		return rnd.nextInt(maxInt);
	}
	
	public static void main(String[] args) {
		int sayi1 = sayiUret(20); //0-20 aras� say� �retir.
		int sayi2 = sayiUret(10); //0-10 aras� say� �retir.
		
		if(sayi1>sayi2) {
			System.out.println("Say� 1, Say� 2'den b�y�kt�r.");
			System.out.println("Say� 1: "+sayi1);
			System.out.println("Say� 2: "+sayi2);
		}else if(sayi2>sayi1) {
			System.out.println("Say� 2, Say� 1'den b�y�kt�r.");
			System.out.println("Say� 1: "+sayi1);
			System.out.println("Say� 2: "+sayi2);
		}else {
			System.out.println("Say�lar e�ittir.");
		}
	}

}
