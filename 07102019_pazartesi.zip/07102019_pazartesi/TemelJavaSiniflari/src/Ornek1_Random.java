import java.util.Random;

public class Ornek1_Random {

	public static void main(String[] args) {
		
		Random rnd = new Random(); //Bir s�n�ftan nesne t�retmek
		int sayi = rnd.nextInt(10); //nesnenin metodunu �a��rd�k.
		System.out.println(sayi);
		
		
		/*
		 Random s�n�f� rastgele bir say� d�nd�rebilmek i�in kullan�lan bir s�n�ft�r.
		 
		 rnd.nextInt() - �rn: 24300
		 rnd.nextInt(5) - 0 ile 5 aras�nda say� �retir
		 */

	}

}
