
public class Ornek6 {

	public static void main(String[] args) {
		
		int[] sayilar = new int[5];
		
		try {
			System.out.println(sayilar[6]);
		}catch (ArrayIndexOutOfBoundsException e) {
			/*
			System.out.println(e.getMessage()); //Hatan�n mesaj�n� yazd�r�r.
			e.printStackTrace(); //Hatay� yazd�r�r.
			*/
			System.out.println("Dizinin olmayan indisine eri�meye �al��t�n�z !");
		}

	}

}
