import java.util.InputMismatchException;
import java.util.Scanner;

public class Ornek1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("L�tfen say� giriniz");

		try {
			int sayi = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("int haricinde farkl� bir t�rde veri girdiniz.");
		} catch (Exception e) {

		}

		/*
		 * try, hata olu�abilme ihtimali olan kodlar�n eklendi�i kod blo�udur.
		 * 
		 * catch, belirli hata t�r�ne g�re, ilgili hatan�n al�nmas� durumunda �al��acak
		 * kod blo�udur.
		 * 
		 * catch bloklar� birden fazla �retilebilir. Tek �art her catch blo�undaki hata
		 * s�n�f�n�n ismi farkl� olmak zorundad�r.
		 * 
		 * finally, iste�e ba�l� olarak eklenen bloktur. catch sonras�nda eklenir. hata
		 * olsa da olmasa da �al��acak kod blo�u manas�na gelir.
		 * 
		 * Olabilecek t�m hatalar� yakalayabilmek i�in, Exception s�n�f� kullan�l�r.
		 * 
		 */

	}

}
