
public class Ornek5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		String yazi = null;
		
		try {
			yazi.charAt(0);
		}catch (NullPointerException e) {
			System.out.println("String'in de�er atamas� yap�lmadan, metoduna eri�ilemez.");
		}
		
		
		
	}

}
