import java.util.LinkedList;

public class LinkedList_Ornek1 {

	public static void main(String[] args) {
		/*
		 LinkedList s�n�f� metotlar�
		 
		 add - eleman ekler
	     addFirst - en ba�a ekler
	     addLast - en sona ekler
	     clear - T�m elemanlar� temizler
	     contains - Listede eleman varl��� sorgusu yapar.
	     get - ilgili indisteki eleman� �a��rmak i�in kullan�l�r.
	     getFirst 
	     getLast
	     indexOf
	     lastIndexOf
	     iterator
	     listIterator
	     remove
	     removeFirst
	     removeLast
		 */
		
		LinkedList<String> linkedList = new LinkedList<>();
		linkedList.add("MERCEDES");
		linkedList.add("AUD�");
		linkedList.add("BMW");

		linkedList.addLast("MURAT");
		linkedList.addFirst("PORSCHE");
		
		for (String string : linkedList) {
			System.out.println(string);
		}
		
		System.out.println("Birinci eleman: "+linkedList.getFirst());
		System.out.println("Son eleman: "+linkedList.getLast());
		
		//�lk eleman� silelim.
		linkedList.removeFirst();
		linkedList.removeLast();
		System.out.println("Birinci eleman: "+linkedList.getFirst());
		System.out.println("Son eleman: "+linkedList.getLast());
		
	}

}
