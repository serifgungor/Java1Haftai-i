import java.util.Enumeration;
import java.util.Vector;

public class Vector_Ornek2 {

	public static void main(String[] args) {
		Vector<String> ulkeler = new Vector<>();
		
		ulkeler.addElement("T�RK�YE CUMHUR�YET�");
		ulkeler.addElement("SUR�YE");
		ulkeler.addElement("K.K.T.C.");
		ulkeler.addElement("RUSYA");
		ulkeler.addElement("YUNAN�STAN");
		ulkeler.addElement("BULGAR�STAN");
		ulkeler.addElement("IRAK");
		ulkeler.addElement("�RAN");
		
		//�TERAT�ON
		Enumeration vectorEnum = ulkeler.elements();
		while (vectorEnum.hasMoreElements()) {
			System.out.println(vectorEnum.nextElement());
		}
		System.out.println("--");
		for (String ulkeAdi:ulkeler) {
			System.out.println(ulkeAdi);
		}
		System.out.println("--");
		for (int i = 0; i < ulkeler.size(); i++) {
			System.out.println(ulkeler.get(i));
		}
		

	}

}
