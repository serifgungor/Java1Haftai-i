import java.util.Stack;

public class Stack_Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		/*
		 push
		 - Listeye eleman ekleme i�lemi yapar.
		 pop
		 - Listenin en �stte bulunan eleman�n� siler. E�er liste bo� ise EmptyStackException hatas� verir.
		 peek
		 - Listenin en �st�ndeki eleman� d�nd�rmek i�in kullan�l�r. Bu eleman� silmez, sadece g�sterir.
		 empty
		 - Listenin bo� olup olmama durumunu kontrol eder.
		 search
		 - Listede eleman arama i�lemi yapmam�z i�in kullan�l�r. Eleman listede varsa indisini d�ner,
		 	listede yoksa -1 d�ner
		 	
		 �lk eklenen en son s�raya, en son eklenen ilk s�raya eklenir.
		 */

		Stack<String> stack = new Stack<>();
		stack.push("MECL�S�");
		stack.push("M�LLET");
		stack.push("B�Y�K");
		stack.push("T�RK�YE");
		
		for (int i = 0; i < 4; i++) {
			System.out.println(stack.pop());
		}
	}

}
