import java.util.ArrayList;

public class ArrayList_Ornek4 {

	public static void main(String[] args) {

		ArrayList<String> liste = new ArrayList<>();
		liste.add("B�LG�SAYAR");
		liste.add("TELEV�ZYON");
		liste.add("KOLTUK");
		liste.add("ARABA");
		
		//Foreach ile liste elemanlar�n� listeleme
		System.out.println("Listedeki de�erler ��yledir:");
		for(String eleman: liste) {
			System.out.println(eleman);
		}
		
		//Remove metodu sayesinde string arg�man g�ndererek de�er sildik
		System.out.println("Listeden KOLTUK de�erini silelim:");
		String silinecekKelime = "KOLTUK";
		liste.remove(silinecekKelime);
		
		//Listenin son halini tekrar ekrana yazd�rd�k.
		System.out.println("Listenin son hali ��yledir:");
		for(String eleman: liste) {
			System.out.println(eleman);
		}
		
	}

}
