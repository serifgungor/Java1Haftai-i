import java.util.ArrayList;

public class ArrayList_Ornek9 {

	public static void main(String[] args) {
		ArrayList<String> meyveler = new ArrayList<>();
		meyveler.add("Elma");
		meyveler.add("�ilek");
		meyveler.add("Nar");
		meyveler.add("Kavun");
		meyveler.add("Kiraz");
		
		//T�m elemanlar� listeledik
		for(String eleman : meyveler) {
			System.out.println(eleman);
		}
		
		meyveler.remove("�ilek"); //Listeden �ilek'i sildik
		
		//T�m elemanlar� listeledik
		for (String string : meyveler) {
			System.out.println(string);
		}
		
		for(int i=0; i<meyveler.size(); i++) {
			System.out.println(meyveler.get(i));
		}
		
		//T�m elemanlar� siler
		meyveler.clear(); 
		
		
		if(meyveler.isEmpty()) {
			System.out.println("Meyveler listesinde eleman yok");
		}else {
			System.out.println("Meyveler listesi doludur.");
		}
		
		

	}

}
