import java.util.Stack;

public class Stack_Ornek1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack stack = new Stack();
		/*
		 Stack s�n�f� Vector s�n�f�ndan t�remi�tir, bu nedenle Stack s�n�f� i�erisinde Vector'de bulunan metot
		 isimleri ile kar��la��labilir.
		 
		 Fakat, Vector'de olmay�p Stack'de ayr�ca eklenmi� metot isimleri ile kar��la�abiliriz.
		 */
		
		/*
		 add
		 addElement
		 capacity
		 elements
		 elementsAt
		 firstElement
		 lastElement
		 get
		 isEmpty
		 lastIndexOf
		 indexOf
		 removeAllElement
		 clear
		 
		 peek
		 pop
		 push
		 empty
		 search
		 */
	
		
		

	}

}
