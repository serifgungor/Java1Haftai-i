import java.util.ArrayList;

public class ArrayList_Ornek8 {

	public static void main(String[] args) {
		ArrayList<Araba> arabalar = new ArrayList<>();
		arabalar.add(new Araba("Marka 1","Model 1",50000,"Beyaz"));
		arabalar.add(new Araba("Marka 2","Model 1",70000,"K�rm�z�"));
		arabalar.add(new Araba("Marka 3","Model 1",120000,"Siyah"));
		
		for (int i = 0; i < arabalar.size(); i++) {
			System.out.println("Araban�n markas�: "+arabalar.get(i).getMarka());
			System.out.println("Araban�n modeli: "+arabalar.get(i).getModel());
			System.out.println("Araban�n fiyat�: "+arabalar.get(i).getFiyat());
			System.out.println("Araban�n rengi: "+arabalar.get(i).getRenk());
			System.out.println("---");
		}

	}

}
