import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class ArrayList_Ornek10 {

	public static void main(String[] args) {
		Random rnd = new Random();
		
		ArrayList<Integer> sayilar = new ArrayList<>();
		
		for (int i = 0; i < 10; i++) {
			sayilar.add(rnd.nextInt(5000));
		}
		
		//toArray metodu sayesinde ArrayList'i diziye �evirdik.
		Object[] intDizi = sayilar.toArray();
		for (Object sayi : intDizi) {
			System.out.println(sayi);
		}
		
		
		System.out.println("----");
		
		ArrayList<String> dersler = new ArrayList<>();
		dersler.add("Java");
		dersler.add("Android");
		dersler.add("Google Seo");
		dersler.add("Wordpress");
		dersler.add("E-Ticaret");
		dersler.add("PHP");
		dersler.add("ASP.net");
		dersler.add("C#");
		dersler.add("Java");
		
		int index = dersler.indexOf("PHP");
		System.out.println(index);
		
		int lastIndex = dersler.lastIndexOf("Java");
		System.out.println(lastIndex);
		
		if(dersler.contains("E-Ticaret")) {
			System.out.println("E-Ticaret dersler listesinde vard�r.");
		}else {
			System.out.println("E-Ticaret dersler listesinde yoktur.");
		}
		
		
	}

}
