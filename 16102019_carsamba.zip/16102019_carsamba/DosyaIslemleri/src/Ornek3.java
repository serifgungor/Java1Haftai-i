import java.io.File;
import java.io.IOException;

public class Ornek3 {
	
	public static void dosyaUret(String path,int uretilecekDosyaSayisi) {
		File dosya = null;
		//Dosya �reten metot
		for (int i = 0; i < uretilecekDosyaSayisi; i++) {
			dosya = new File(path+"/dosya_"+i+".txt");
			try {
				dosya.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public static void dosyalariSil(String path) {
		File dosya = new File(path);
		File[] dosyalar = dosya.listFiles();
		
		for (int i = 0; i < dosyalar.length; i++) {
			dosyalar[i].delete();
		}
	}
	
	public static void dosyalariListele(String path) {
		File dosya = new File(path);
		File[] dosyalar = dosya.listFiles();
		
		for (int i = 0; i < dosyalar.length; i++) {
			System.out.println(dosyalar[i].getName());
		}
	}
	
	public static boolean belirtilenDosyayiSil(String path) {
		boolean b = false;
		File f = new File(path);
		if(f.delete()) {
			b=true;
		}
		return b;
	}
	

	public static void main(String[] args) {

		dosyaUret("Z:/�SMEK",20);
		dosyalariListele("Z:/�SMEK");
		//dosyalariSil("Z:/�SMEK");
		if(belirtilenDosyayiSil("Z:/�SMEK/dosya_18.txt")) {
			System.out.println("Dosya silindi");
		}
		
		

	}

}
