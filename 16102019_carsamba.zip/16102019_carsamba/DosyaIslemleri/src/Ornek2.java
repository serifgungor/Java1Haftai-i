import java.io.File;

public class Ornek2 {

	public static void main(String[] args) {
		File f = new File("Z:/�SMEK");
		
		if(f.mkdir()) {
			System.out.println("Klas�r �retildi");
		}else {
			System.out.println("Klas�r �retilemedi");
		}

	}

}
