import java.io.File;
import java.io.IOException;

public class Ornek1 {

	public static void main(String[] args) {
		// File s�n�f� metotlar�
		
		File dosya = new File("Z:/serifgungor.txt");
		// Z > serifgungor klas�r�n� �al��mak ama�l� baz al�r. (Konumu i�aret eder)
		
		try {
			boolean dosyaUretildiMi = dosya.createNewFile();
			if(dosyaUretildiMi) {
				System.out.println("Z i�erisinde serifgungor.txt dosyas� �retildi");
			}else {
				System.out.println("Z i�erisinde serifgungor.txt dosyas� �retilemedi.");
				/*
				 false d�nmesinin sebebi Z diski bulunamad��� i�in olabilir.
				 yada Z diskinde zaten serifgungor.txt dosyas� daha �nceden olu�turulmu� olabilir.
				 */
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		/*
		 canExecute	- 
		 canRead
		 canWrite
		 delete
		 exists
		 createNewFile
		 getAbsolutePath
		 getName
		 getPath
		 isAbsolute
		 isHidden
		 isDirectory
		 isFile
		 list
		 listFiles
		 length
		 mkDir
		 */

		

	}

}
