
public class Ornek4 {

	public static void main(String[] args) {
		
		String ad = "�erif";
		String soyad = "g�ng�r";
		
		if("�erif".equals(ad) && "g�ng�r".equals(soyad))
			System.out.println("Merhaba");
		else
			System.out.println("Sizi tan�m�yorum..");
		
		
		/*
		 If statement, s�sl� parantez olmadan da kullan�labilir.
		 if, else if yada else sat�r�ndan sonra bir girinti(tab tu�u)
		 olu�turup sadece bir sat�r olarak kod yazabiliriz.
		 
		 E�er if yap�s�nda s�sl� parantez varsa istedi�imiz kadar
		 sat�r olu�turup kodlar� yazabiliriz.
		 */

	}

}
