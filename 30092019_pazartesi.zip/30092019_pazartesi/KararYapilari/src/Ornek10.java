import java.util.Scanner;

public class Ornek10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String isim = sc.next();
		
		/*
		 String ifadede b�y�k k���k harf ayr�m� yapmadan de�er kontrol�
		 sa�lamak istiyorsak equalsIgnoreCase kullanabiliriz.
		 */
		if("ismek".equalsIgnoreCase(isim)) {
			System.out.println("Giri� ba�ar�l�");
		}else {
			System.out.println("Giri� hatal�");
		}
		

	}

}
