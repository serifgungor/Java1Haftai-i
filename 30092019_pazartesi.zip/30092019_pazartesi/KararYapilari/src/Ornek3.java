import java.util.Scanner;

public class Ornek3 {

	static Scanner sc;
	public static void main(String[] args) {
		
		int sayi1,sayi2,sonuc;
		sc = new Scanner(System.in);
		System.out.println("L�tfen 1. say�y� giriniz");
		sayi1=sc.nextInt();
		System.out.println("L�tfen 2. say�y� giriniz");
		sayi2 = sc.nextInt();
		System.out.println("��lem se�iniz (topla,��kar,�arp,b�l)");
		String islem = sc.next();
		
		if("topla".equals(islem)) {
			sonuc = sayi1+sayi2;
			System.out.println("Toplama i�lemi sonucu: "+sonuc);
		}else if("��kar".equals(islem)) {
			sonuc = sayi1-sayi2;
			System.out.println("��karma i�lemi sonucu: "+sonuc);
		}else if("�arp".equals(islem)) {
			sonuc = sayi1*sayi2;
			System.out.println("�arpma i�lemi sonucu: "+sonuc);
		}else if("b�l".equals(islem)) {
			sonuc = sayi1/sayi2;
			System.out.println("B�lme i�lemi sonucu: "+sonuc);
		}
		
	}

}
