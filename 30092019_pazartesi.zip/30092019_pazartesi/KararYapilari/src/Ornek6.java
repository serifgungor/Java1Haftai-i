import java.util.Scanner;

public class Ornek6 {

	static Scanner sc;
	public static void main(String[] args) {
		
		System.out.println("��lem se�iniz: (kare,daire,dikd�rtgen)");
		String islem = sc.next();
		
		if("kare".equals(islem)) {
			
			System.out.println("Bir kenar�n uzunlu�unu giriniz");
			int kenarUzunlugu = sc.nextInt();
			int alan = kenarUzunlugu*kenarUzunlugu;
			int cevre = kenarUzunlugu*4;
			System.out.println("Karenin alan�: "+alan);
			System.out.println("Karenin �evresi: "+cevre);
			
		}else if("daire".equals(islem)) {
			
			System.out.println("Dairenin yar��ap�n� giriniz");
			double r = sc.nextDouble();
			double PI=3.14;
			
			double alan = PI*r*r;
			double cevre = 2*PI*r;
			System.out.println("Dairenin alan�: "+alan);
			System.out.println("Dairenin �evresi: "+cevre);
			
			
		}else if("dikd�rtgen".equals(islem)) {
			System.out.println("Dikd�rtgenin k�sa kenar�n� giriniz");
			int kisaKenar = sc.nextInt();
			System.out.println("Dikd�rtgenin uzun kenar�n� giriniz");
			int uzunKenar = sc.nextInt();
			
			int alan = kisaKenar*uzunKenar;
			int cevre = 2*(kisaKenar+uzunKenar);
			System.out.println("Dikd�rtgenin alan�: "+alan);
			System.out.println("Dikd�rtgenin �evresi: "+cevre);
			
		}else {
			System.out.println("Yanl�� i�lem girdiniz !");
		}
	
		//Kare, Daire, Dikd�rtgen
		

	}

}
