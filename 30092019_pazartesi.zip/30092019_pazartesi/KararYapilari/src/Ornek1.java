import java.util.Scanner;

public class Ornek1 {
	
	/*
	 Ko�ullu ��lemler (Karar Yap�lar�)
	 
	 if
	 if-else
	 if-else if-else
	 switch-case
	 
	 */
	
	static Scanner sc;

	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		
		System.out.println("L�tfen ad�n�z� giriniz: ");
		String ad = sc.next();
		System.out.println("L�tfen soyad�n�z� giriniz: ");
		String soyad = sc.next();
		int yas = 1;
		
		if(yas==1) {
			System.out.println("MERHABA :)");
		}
		
		/*
		 Basit veri tipleri == ile k�yaslan�r.
		 String ise, string s�n�f�n�n equals metodu ile k�yaslan�r.
		 */
		
		if("�erif".equals(ad) && "g�ng�r".equals(soyad)) {
			System.out.println("MERHABA, �ER�F G�NG�R");
		}
		
	}

}
