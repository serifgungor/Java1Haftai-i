import java.util.Scanner;

public class Ornek8 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("L�tfen mevsim giriniz:");
		String mevsim = sc.next();
		
		/*
		 case bloklar� duplicate edilemez(kopyalanamaz)
		 */
		
		switch(mevsim) {
			case "sonbahar":
				System.out.println("Ekim, Kas�m, Aral�k");
				break;
			case "k��":
				System.out.println("Ocak, �ubat, Mart");
				break;
			case "ilkbahar":
				System.out.println("Nisan, May�s, Haziran");
				break;
			case "yaz":
				System.out.println("Temmuz, A�ustos, Eyl�l");
				break;
			default:
				System.out.println("B�yle bir mevsim bulunmamaktad�r.");
			/*
				Hi�bir �art ger�ekle�mez ise default blo�una d��er.
			*/
				break;
				
		}
		
		
	}

}
