
public class Ornek7 {

	public static void main(String[] args) {
		
		int sayi = 5;
		if(sayi==5) {
			//sayi 5 ise ger�ekle�ecek i�lem
		}else {
			//say� 5 de�il ise, say�y� 5 olarak g�ncelle
			sayi = 5;
		}
		
		// ��L� OPERAT�R
		
		int sayi1 = 5;
		int sayi2 = 7;
		
		int enDusukSayi = (sayi1<sayi2) ? sayi1: sayi2;
		System.out.println(enDusukSayi);
		
		/*
		 	veriTipi degiskenAdi = (�ART) ? EVET : HAYIR;
		  ? �ncesi olan parantezde �art ger�ekle�irse
		  ? sonras� olan k�s�m �al���r.
		  �art sa�lanmaz ise : sonras� olan k�s�m �al���r.
		 */
		
		boolean okuyorMusun = false;
		
		String yanit = okuyorMusun ? "Evet": "Hay�r";
		System.out.println(yanit);
		
		
		

	}

}
