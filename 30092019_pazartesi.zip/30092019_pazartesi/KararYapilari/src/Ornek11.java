
public class Ornek11 {

	public static void main(String[] args) {
		
		//Kelimede A olmayan karakterleri yazd�rma �rne�i
		String metin = "MERHABA D�NYA";
		
		int uzunluk = metin.length();
		
		for(int i=0; i<uzunluk; i++) {
			if(metin.charAt(i)!='A') {
				System.out.print(metin.charAt(i));
			}
		}

	}

}
