
public class Ornek6 {

	public double alan(double kenarUzunlugu) {
		return kenarUzunlugu*kenarUzunlugu;
	}
	
	public double cevre(double kenarUzunlugu) {
		return 4*kenarUzunlugu;
	}
	
	public static void main(String[] args) {
		// Karenin alan ve �evre hesaplamas�n� yapan metotlar �retiniz.
		
		Ornek6 kare = new Ornek6();
		System.out.println("Karenin alan�");
		System.out.println(kare.alan(10.0));
		
		System.out.println("Karenin �evresi");
		System.out.println(kare.cevre(10.0));
		
	}

}
