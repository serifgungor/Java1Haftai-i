
public class Ornek8 {
	
	public void sayilariDon(int baslangicDegeri,int bitisDegeri,char ch) {
		// ch -> T,�
		for (int i = baslangicDegeri; i <=bitisDegeri; i++) {
			if(ch=='T' || ch == 't') {
				//Sadece tekleri yazd�r�r
				if(i%2!=0) {
					System.out.println(i);
				}
			}else if(ch=='�' || ch == '�') {
				//Sadece �iftleri yazd�r�r.
				if(i%2==0) {
					System.out.println(i);
				}
			}
		}
	}

	public static void main(String[] args) {
		/*
		 Belirtti�imiz ba�lang�� ve biti� indisleri aras�ndaki tek yada �ift de�erleri yazd�ran metot �retiriniz.
		 */
		Ornek8 o = new Ornek8();
		o.sayilariDon(10, 50, 'T');
	}

}
