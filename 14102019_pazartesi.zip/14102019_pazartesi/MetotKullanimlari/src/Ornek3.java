
public class Ornek3 {
	
	public void sayilariSay(int baslangicDegeri,int bitisDegeri,int artisMiktari) {
		for (int i = baslangicDegeri; i <= bitisDegeri; i+=artisMiktari) {
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		
		Ornek3 o = new Ornek3();
		o.sayilariSay(10, 50, 5);

	}

}
