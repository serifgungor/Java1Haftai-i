import java.util.Scanner;

public class Ornek5 {
	
	// Metot ile Daire alan ve �evre hesaplamas�
	
	public float alan(float yaricap) {
		return (float)Math.PI*yaricap*yaricap;
	}
	
	public float cevre(float yaricap) {
		return (float) (2*Math.PI*yaricap);
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Yar��ap giriniz:");
		float r = sc.nextFloat();
		Ornek5 daire = new Ornek5();
		System.out.println("Dairenin alan�: "+daire.alan(r));
		System.out.println("Dairenin �evresi: "+daire.cevre(r));

	}

}
