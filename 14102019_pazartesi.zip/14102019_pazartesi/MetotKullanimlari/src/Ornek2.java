
public class Ornek2 {
	
	public void ad(String ad) {
		System.out.println(ad);
	}
	public void soyad(String soyad) {
		System.out.println(soyad);
	}
	public void adSoyad(String ad,String soyad) {
		System.out.println(ad+" "+soyad);
	}
	public void adSoyad(String ad,String soyad,int yas) {
		System.out.println(ad+" "+soyad);
	}
	public void adSoyad(String adSoyad) {
		System.out.println(adSoyad);
	}
	

	public static void main(String[] args) {
		
		/*
		 �mzalar(Arg�man listesi) farkl� oldu�u s�rece ayn� metot isminden istedi�imiz kadar �retebiliriz.
		 �mzalar ayn� olup, geri d�n�� tipleri farkl� olursa yine o metot �retilemez.
		 */
		
		Ornek2 orn2 = new Ornek2();
		orn2.ad("�ER�F");
		orn2.soyad("G�NG�R");
		orn2.adSoyad("�ER�F", "G�NG�R");

	}

}
