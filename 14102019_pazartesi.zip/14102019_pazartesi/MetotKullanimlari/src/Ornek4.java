
public class Ornek4 {
	
	public void diziElemanlariniYazdir(int[] dizi) {
		for (int i = 0; i < dizi.length; i++) {
			System.out.println(dizi[i]);
		}
	}

	public static void main(String[] args) {
		int[] sayilar = {1,20,4,5,6};
		
		Ornek4 o = new Ornek4();
		o.diziElemanlariniYazdir(sayilar);
		

	}

}
