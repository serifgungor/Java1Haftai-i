
public class Ornek9 {

	public void donguFor(int bitisSayisi) {
		for (int i = 0; i <= bitisSayisi; i++) {
			System.out.println(i);
		}
	}
	
	public void donguWhile(int bitisSayisi) {
		int i=0;
		while (i<bitisSayisi) {
			System.out.println(i);
			i++;
		}
	}
	
	public void donguDoWhile(int bitisSayisi) {
		int sayi = 0;
		do {
			System.out.println(sayi);
			sayi++;
		}while(sayi<bitisSayisi);
	}
	
	public static void main(String[] args) {
		Ornek9 o = new Ornek9();
		System.out.println("For Kullan�m�");
		o.donguFor(5);
		System.out.println("While Kullan�m�");
		o.donguWhile(10);
		System.out.println("Do-While Kullan�m�");
		o.donguDoWhile(15);

	}

}
