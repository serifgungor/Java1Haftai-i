import java.util.Scanner;

public class Ornek7 {

	public double alan(double kisaKenar,double uzunKenar) {
		return kisaKenar*uzunKenar;
	}
	
	public double cevre(double kisaKenar,double uzunKenar) {
		return 2*(kisaKenar+uzunKenar);
	}
	
	
	public static void main(String[] args) {
		// Dikd�rtgenin alan ve �evre hesaplamas�n� yapan metotlar �retiniz
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen dikd�rtgenin k�sa kenar�n� giriniz");
		double kisaKenar = sc.nextDouble();
		System.out.println("L�tfen dikd�rtgenin uzun kenar�n� giriniz");
		double uzunKenar = sc.nextDouble();
		
		Ornek7 dikdortgen = new Ornek7();
		double alan = dikdortgen.alan(kisaKenar, uzunKenar);
		double cevre = dikdortgen.cevre(kisaKenar, uzunKenar);
		System.out.println("Dikd�rtgenin alan�: "+alan);
		System.out.println("Dikd�rtgenin �evresi: "+cevre);
		
	}

}
