import java.util.ArrayList;

public class ArrayList_Ornek7 {

	public static void main(String[] args) {
	
		ArrayList<Hayvan> hayvanlar = new ArrayList<>();
		hayvanlar.add(new Hayvan("Kedi",1,"Beyaz"));
		hayvanlar.add(new Hayvan("K�pek",2,"Kahverengi"));
		hayvanlar.add(new Hayvan("Timsah",7,"Ye�il"));
		
		for (Hayvan hayvan : hayvanlar) {
			System.out.println("Hayvan�n ad�: "+hayvan.getAd());
			System.out.println("Hayvan�n ya��: "+hayvan.getYas());
			System.out.println("Hayvan�n rengi: "+hayvan.getRenk());
			System.out.println("--");
		}

	}

}
