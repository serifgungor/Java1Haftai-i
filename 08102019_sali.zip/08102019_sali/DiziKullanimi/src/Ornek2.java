import java.util.Scanner;

public class Ornek2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		String[] dizi = new String[3];
		
		System.out.println("1. eleman� giriniz");
		dizi[0] = sc.next();
		System.out.println("2. eleman� giriniz");
		dizi[1] = sc.next();
		System.out.println("3. eleman� giriniz");
		dizi[2] = sc.next();
		
		System.out.println(dizi[0]);
		System.out.println(dizi[1]);
		System.out.println(dizi[2]);
		
		
	}

}
