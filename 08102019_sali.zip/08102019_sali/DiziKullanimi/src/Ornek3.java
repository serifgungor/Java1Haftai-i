
public class Ornek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Object[] obj = new Object[3];
		obj[0] = 5;
		obj[1] = "Merhaba";
		obj[2] = true;
		
		System.out.println(obj[0]);
		System.out.println(obj[1]);
		System.out.println(obj[2]);
		
		
	}

}
