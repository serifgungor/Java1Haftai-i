import java.util.Scanner;

public class Ornek3 {

	public static void main(String[] args) {
		/*
		 5 elemanl� bir string dizisi �ret, her de�eri kullan�c�dan iste.
		 
		 Yeni bir d�ng� �ret, kullan�c�dan istedi�in t�m de�erleri
		 ekrana yazd�rs�n.
		 
		 */
		
		Scanner sc = new Scanner(System.in);
		String[] dizi = new String[5];
		
		for (int i = 0; i < 5; i++) {
			System.out.println((i+1)+". de�eri giriniz");
			dizi[i] = sc.next();
		}
		
		for (int i = 0; i < 5; i++) {
			System.out.println(dizi[i]);
		}
		
		
	}

}
