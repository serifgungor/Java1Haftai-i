
public class Ornek2 {

	public static void main(String[] args) {
		// S�f�rdan ba�lay�p 5'e kadar olan say�lar� ekranda yazd�rma
		
		//Birer birer artt�rma
		for(int i=0; i<=5; i++) {
			System.out.println(i);
		}
		System.out.println("***");
		
		// �ki�er iki�er artt�rma
		for(int i=0; i<=20; i+=2) {
			System.out.println(i);
		}
		System.out.println("***");
		
		// 100'den ba�lay�p, 50'ye kadar olan say�lar� yazd�rma
		for(int i=100; i>=50; i-=5) {
			System.out.println(i);
		}
		System.out.println("***");
		
		// sonsuz d�ng�
		int s = 0;
		for(;;) {
			s++;
			System.out.println("Merhaba");
			if(s==20) {
				break;
			}
		}
		System.out.println("***");
		
		//Belirtti�imiz say� kadar artt�rma
		
		int artisMiktari = 5;
		for(int i=0; i<=500; i+=artisMiktari) {
			if(i==200) {
				artisMiktari = 4;
			}
			System.out.println(i);
		}
		System.out.println("***");
		
		//Belirtti�imiz say� kadar �arpma
		
		for(int i=1; i<=500; i*=5) { System.out.println(i); }
		
		

	}

}
