import java.util.Scanner;

public class Ornek4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ka�a kadar sayd�rs�n ?");
		int bitisSayisi = sc.nextInt();
		
		System.out.println("Ka� ka� artt�rs�n ?");
		int artisMiktari = sc.nextInt();
		
		for(int i=0; i<=bitisSayisi; i+=artisMiktari) {
			System.out.println(i);
		}

	}

}
