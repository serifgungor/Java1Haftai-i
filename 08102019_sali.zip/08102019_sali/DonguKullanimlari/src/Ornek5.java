import java.util.Scanner;

public class Ornek5 {

	public static void main(String[] args) {
		// Akrosti� �rne�i
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Ka� adet kelime gireceksiniz ?");
		int n = sc.nextInt();
		
		String[] dizi = new String[n];
		//Kelimeleri giriyoruz
		for(int i=0; i<n; i++) {
			dizi[i] = sc.next();
		}
		
		//Kelimelerin ilk karakterlerini yeni bir string'e at�yoruz.
		String yeniKelime = "";
		for(int i=0; i<n; i++) {
			yeniKelime += dizi[i].charAt(0); // ilk karakteri ald�k
		}
		
		//yeni kelimeyi yazd�r�yoruz.
		System.out.println(yeniKelime);

		
	}

}
